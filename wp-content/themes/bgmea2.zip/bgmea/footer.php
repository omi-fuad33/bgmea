<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package bgmea
 */

?>

	</div><!-- #content -->

	<footer class="o_site_footer_container container-fluid">
		<div class="container o_footer_container">
			<div class="row">
				<div class="col-lg-3">
					<h6 class="o_footer_head">Contact</h6>
					<p class="o_footer_para_text">BGMEA Bhavan<br>Sector 17, Uttara<br>Dhaka-1000, Bangladesh</p>
					<p class="o_footer_para_text">Phone: +880 2 9523652</p>
					<p class="o_footer_para_text o_footer_text_tab">+880 17 218 927<br> +880 17 555 367</p>
					<p class="o_footer_para_text">Email: contact@bgmea.com.bd</p>
					<p class="o_footer_para_text o_footer_text_tab">info@bgmea.com.bd</p>
				</div>
				<div class="col-lg-7">
				<div class="mapouter"><div class="gmap_canvas"><iframe width="600" height="240" id="gmap_canvas" src="https://maps.google.com/maps?q=bgmea%20New%20building&t=&z=15&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.emojilib.com"></a></div><style>.mapouter{position:relative;text-align:right;height:240px;width:600px;}.gmap_canvas {overflow:hidden;background:none!important;height:240px;width:600px;}</style></div>
				</div>
				<div class="col-lg-2">
					<h6 class="o_footer_head o_footer_head_right">Quick Links</h6>
					<div class="footer_nav_container">
						<?php wp_nav_menu( array( 'theme_location' => 'footer-menu' ) ); ?>
					</div>
				</div>
			</div>
			<div class="row">
			<div class="col-lg-3"></div>
			<div class="col-lg-6 o_footer_bgmea_logo">
				<img src="<?php echo get_template_directory_uri(); ?>/css/images/BGMEA_Logo.png" class="header-logo">
			</div>
			<div class="col-lg-3 d_social">
				<div class="d_s_media">
					<i class="fa fa-facebook-square d_s_icon"></i>
					<i class="fa fa-twitter-square d_s_icon"></i>
					<i class="fa fa-instagram d_s_icon"></i>
					<i class="fa fa-linkedin d_s_icon"></i>
					<i class="fa fa-youtube-square d_s_icon"></i>
				</div>
			</div>
		</div>
	</footer>
	<div class="o_footer_omnispace">
			Allrights Reserved | Developed By: Omnispace
		</div>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
