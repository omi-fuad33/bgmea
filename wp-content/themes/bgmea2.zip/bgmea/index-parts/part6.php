<!-- Omi's part -->
<section class="container o_front_gallery_section_wrapper">
<h2 class="o_gallery_section_header">Gallery</h2>
<div class="o_front_gallery_section_inner_wrapper">
    <div class="row">
        <div class="col-lg-8">
            <div class="gallery_slider_wrapper">
                <img src="<?php echo get_home_url(); ?>/wp-content/uploads/2019/11/bgmea_building_4-1024x683.jpg" alt="image-not-found">
            </div>
        </div>
        <div class="col-lg-4">
        <div class="o_gallery_video_img">
                <img src="<?php echo get_home_url(); ?>/wp-content/uploads/2019/11/bgmea_building_4-1024x683.jpg" alt="image-not-found">
            </div>
            <div class="o_gallery_video_img">
                <img src="<?php echo get_home_url(); ?>/wp-content/uploads/2019/11/bgmea_building_4-1024x683.jpg" alt="image-not-found">
            </div>
        </div>
    </div>
</div>
</section>
