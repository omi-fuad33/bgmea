<form role="search" method="get" id="searchform" class="searchform" action="<?php echo get_home_url(); ?>">
<div class="d_search">
      <input type="text" value="" name="s" placeholder="Search..." />
      <button type="submit" id="searchsubmit" />
           <span class="d_icon"><i class="fa fa-search"></i></span>
      </button>
</div>
</form>
