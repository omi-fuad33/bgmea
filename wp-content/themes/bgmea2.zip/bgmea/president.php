<?php
/* Template Name: President */

get_header();
?>
<div class="container d_president_wrapper">
        <h2>President's Profile</h2>
  <div class="row  d_president">
        <div class="col-sm-12 col-md-4 d_pre_img_det">
      <?php
                $post_id = 195;
                $queried_post = get_post($post_id);
                $content = $queried_post->post_content;
                $image_id = get_post_thumbnail_id(195);
        $image_url = wp_get_attachment_image_src($image_id, 'full', true);?>

           <img class="img-responsive"  src="<?php echo $image_url[0]; ?>"><br><br>
           <div class="d_president_details">
             <h3>Dr. Rubana Huq</h3>
             <p>President, BGMEA &</p>
             <p>Managing Director, Mohammadi Group Ltd.</p>
             <p>57, Joar Sahara C/A, Nikunja-2</p>
            <p>New Airport Road, Dhaka</p>
             <p>Tel: 8802-8952704</p>
             <p>Email: president@bgmea.com,</p>
             <p>rubana@mohammadigroup.com</p>
           </div>
    </div>
    <div class="col-sm-12 col-md-8">
      <div class="d_president_content"><?php echo $content;?></div>
    </div>
  </div>
</div>

<?php
get_footer();
